<?php 
$connect = mysqli_connect("localhost", " ", " ", " ");
if(isset($_POST["prim_skills"]))
{
 $prim_skills = '';
 foreach($_POST["prim_skills"] as $row)
 {
  $prim_skills .= $row . ', ';
 }
 $prim_skills = substr($prim_skills, 0, -2);
 $query = "INSERT INTO like_table(prim_skills) VALUES('".$prim_skills."')";
 if(mysqli_query($connect, $query))
 {
  echo 'Data Inserted';
 }
}
?>