REPLACE INTO x_option VALUES ('CÔTE', 'Côte d''Ivoire', '2005-02-03 18:40:45', 'AJM', NULL, NULL);
REPLACE INTO x_option VALUES ('ELEPHANT', 'Eléphânt', '2003-01-01 12:00:00', 'AJM', '2005-06-27 12:39:06', 'AJM');
